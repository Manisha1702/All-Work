package com.cg.hbms.dto;

import java.sql.Date;
import java.time.LocalDate;
import java.lang.String;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="bookingdetails")
public class BookingDetails 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@SequenceGenerator(name="seq",sequenceName="booking_id_seq") 
	@Column(name="booking_id")	
	private Integer id;
	
	@Column(name="room_id")
	private String roomId;
	
	@Column(name="user_id")
	//@NotEmpty(message="userid should be of 4 digits")
	private String userId;
	
	@Column(name="booked_from")
	//@NotEmpty(message="Check In Date should be in dd/mm/yyyy")
	private Date bookFrom;
	
	@Column(name="booked_to")
	//@NotEmpty(message="Check Out Date should be in dd/mm/yyyy")
	private Date bookTo;
	
	@Column(name="no_of_adults")
	private int noOfAdults;
	
	@Column(name="no_of_children")
	private int noOfChildren;
	
	@Column(name="amount")
	private double amount;

	@Override
	public String toString() 
	{
		return "BookingDetails [id=" + id + ", roomId=" + roomId + ", userId=" + userId + ", bookFrom=" + bookFrom
				+ ", bookTo=" + bookTo + ", noOfAdults=" + noOfAdults + ", noOfChildren=" + noOfChildren + ", amount="
				+ amount + "]";
	}

	public BookingDetails(String roomId, String userId, Date bookFrom, Date bookTo, int noOfAdults,
			int noOfChildren) {
		super();
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
	}

	public BookingDetails( String roomId, String userId,Date bookFrom,Date bookTo, int noOfAdults,
			int noOfChildren, double amount) {
		super();
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}

	public BookingDetails(Integer id, String roomId, String userId,Date bookFrom,Date bookTo, int noOfAdults,
			int noOfChildren, double amount) {
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.amount = amount;
	}
	public BookingDetails(Integer id, String roomId, String userId,Date bookFrom,Date bookTo, int noOfAdults,
			int noOfChildren) {
		super();
		this.id = id;
		this.roomId = roomId;
		this.userId = userId;
		this.bookFrom = bookFrom;
		this.bookTo = bookTo;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;		
	}
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getRoomId() {
		return roomId;
	}

	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Date getBookFrom() {
		return bookFrom;
	}

	public void setBookFrom(Date bookFrom) {
		this.bookFrom = bookFrom;
	}

	public Date getBookTo() {
		return bookTo;
	}

	public void setBookTo(Date bookTo) {
		this.bookTo = bookTo;
	}

	public int getNoOfAdults() {
		return noOfAdults;
	}

	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}

	public int getNoOfChildren() {
		return noOfChildren;
	}

	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BookingDetails() {
		super();
		// TODO Auto-generated constructor stub
}
}
