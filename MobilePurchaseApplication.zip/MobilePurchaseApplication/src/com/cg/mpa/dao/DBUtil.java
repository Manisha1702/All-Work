package com.cg.mpa.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mpa.exception.MobileException;

public class DBUtil 
{

	public DBUtil() {
		// TODO Auto-generated constructor stub
	}
	public static Connection getCon() throws SQLException,MobileException
	{
		Connection conn=null;
	    InitialContext context;
	    {
	    	
	    		try {
	    		InitialContext ic=new InitialContext();
	    		DataSource ds= (DataSource)ic.lookup("java:/jdbc/OracleDS");
	    		conn=ds. getConnection();
				} 
	    		catch (NamingException e) {
					throw new MobileException("Problem in obtaining DataSource:"+e.getMessage());
					
				}catch (SQLException e){
					throw new MobileException("Problem in obtaining Connection from datasource:"+e.getMessage());
				}
	    	
	    		return conn;
	    	}
	    }
		
	}


