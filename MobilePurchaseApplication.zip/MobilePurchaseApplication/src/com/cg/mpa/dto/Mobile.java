package com.cg.mpa.dto;

public class Mobile 
{
     private long mobileid;
     private String mname;
     private double price;
     private int quantity;
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getMobileid() {
		return mobileid;
	}
	public void setMobileid(long mobileid) {
		this.mobileid = mobileid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Mobile(long mobileid, String mname, double price, int quantity) {
		super();
		this.mobileid = mobileid;
		this.mname = mname;
		this.price = price;
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobileid=" + mobileid + ", mname=" + mname + ", price="
				+ price + ", quantity=" + quantity + "]";
	}
     
}
