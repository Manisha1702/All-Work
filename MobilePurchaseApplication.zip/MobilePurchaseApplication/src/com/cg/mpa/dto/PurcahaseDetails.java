package com.cg.mpa.dto;

import java.time.LocalDate;

public class PurcahaseDetails 
{
  private long purchaseid;
  private String cname;
  private String mailid;
  private long phoneno;
  private LocalDate purchaseDate;
  private long mobileid;
public PurcahaseDetails() {
	super();
	// TODO Auto-generated constructor stub
}
public long getPurchaseid() {
	return purchaseid;
}
public void setPurchaseid(long purchaseid) {
	this.purchaseid = purchaseid;
}
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public long getPhoneno() {
	return phoneno;
}
public void setPhoneno(long phoneno) {
	this.phoneno = phoneno;
}
public LocalDate getPurchaseDate() {
	return purchaseDate;
}
public void setPurchaseDate(LocalDate purchaseDate) {
	this.purchaseDate = purchaseDate;
}
public long getMobileid() {
	return mobileid;
}
public void setMobileid(long mobileid) {
	this.mobileid = mobileid;
}
public PurcahaseDetails(long purchaseid, String cname, String mailid,
		long phoneno, LocalDate purchaseDate, long mobileid) {
	super();
	this.purchaseid = purchaseid;
	this.cname = cname;
	this.mailid = mailid;
	this.phoneno = phoneno;
	this.purchaseDate = purchaseDate;
	this.mobileid = mobileid;
}
@Override
public String toString() {
	return "PurcahaseDetails [purchaseid=" + purchaseid + ", cname=" + cname
			+ ", mailid=" + mailid + ", phoneno=" + phoneno + ", purchaseDate="
			+ purchaseDate + ", mobileid=" + mobileid + "]";
}
  
  
}
